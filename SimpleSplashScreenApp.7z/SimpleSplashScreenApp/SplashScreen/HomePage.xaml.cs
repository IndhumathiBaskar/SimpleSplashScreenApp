namespace SplashScreen;

public partial class HomePage : ContentPage
{
	public HomePage()
	{
		InitializeComponent();
	}
}